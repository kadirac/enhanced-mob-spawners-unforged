# enhanced-mob-spawners
Mod for Minecraft Forge

Adds harvest and ability to retrieve Monster Egg from Mob Spawners

 

+ Make Mob Spawners minable with silk touch

+ Right-click on a mob spawner and it will drop its monster egg corresponding to what type of entity inside.

+ Adds a approx. 4% chance for all entitys to dropp its monster egg.

 

If a mob spawner, with any entity inside, is harvested with a silk touch it will only drop the block and not the egg. Therefore, retrieve the egg before breaking the block.
